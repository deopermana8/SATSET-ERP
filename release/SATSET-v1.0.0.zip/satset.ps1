﻿param(
    [Parameter(Position=0)]
    [string]$Command,

    [Parameter(Position=1)]
    [string]$Type,

    [Parameter(Position=2)]
    [string]$Name,

    [switch]$Force,

    [switch]$Full
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Generator = Join-Path $Root "tools\generators"

switch ($Command.ToLower()) {

    "doctor" {

        & powershell -ExecutionPolicy Bypass -File "$Root\tools\commands\doctor.ps1"
        exit $LASTEXITCODE
    }

    "test" {

        & powershell -ExecutionPolicy Bypass -File "$Root\tools\commands\test.ps1"
        exit $LASTEXITCODE
    }

    "version" {

        & powershell -ExecutionPolicy Bypass -File "$Root\tools\commands\version.ps1"
        exit $LASTEXITCODE
    }

    "help" {

        & powershell -ExecutionPolicy Bypass -File "$Root\tools\commands\help.ps1"
        exit $LASTEXITCODE
    }

    "docs" {

        & powershell -ExecutionPolicy Bypass -File "$Root\tools\commands\docs.ps1"
        exit $LASTEXITCODE
    }

    "build" {

        & powershell -ExecutionPolicy Bypass -File "$Root\tools\commands\build.ps1"
        exit $LASTEXITCODE
    }

    "make" {

        if ([string]::IsNullOrWhiteSpace($Type)) {
            Write-Host "[FAIL] Missing generator type." -ForegroundColor Red
            exit 1
        }

        switch ($Type.ToLower()) {

            "module" {

                if ($Full) {
                    $Generators = @(
                        'module',
                        'crud',
                        'resource',
                        'entity',
                        'column',
                        'relation',
                        'validation',
                        'form',
                        'sql',
                        'migration',
                        'seeder',
                        'menu',
                        'permission',
                        'sidebar',
                        'route',
                        'api',
                        'openapi'
                    )

                    foreach ($GeneratorType in $Generators) {
                        $GeneratorScript = Join-Path $Generator "$GeneratorType.ps1"
                        Write-Host "[INFO] Running generator: $GeneratorType" -ForegroundColor Cyan
                        if ($Force) {
                            & powershell -ExecutionPolicy Bypass -File $GeneratorScript -Name $Name -Force
                        }
                        else {
                            & powershell -ExecutionPolicy Bypass -File $GeneratorScript -Name $Name
                        }

                        if ($LASTEXITCODE -ne 0) {
                            Write-Host "[FAIL] Generator failed: $GeneratorType" -ForegroundColor Red
                            exit $LASTEXITCODE
                        }
                    }

                    Write-Host "====================" -ForegroundColor Green
                    Write-Host "SATSET BUILD SUCCESS" -ForegroundColor Green
                    Write-Host "====================" -ForegroundColor Green
                    Write-Host "" -ForegroundColor Green
                    Write-Host "Module" -ForegroundColor Green
                    Write-Host "Metadata" -ForegroundColor Green
                    Write-Host "Database" -ForegroundColor Green
                    Write-Host "Frontend" -ForegroundColor Green
                    Write-Host "Backend" -ForegroundColor Green
                    Write-Host "OpenAPI" -ForegroundColor Green
                    Write-Host "Generated Successfully" -ForegroundColor Green
                    exit 0
                }

                if ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\module.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\module.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "crud" {

                if ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\crud.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\crud.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "resource" {

                if ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\resource.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\resource.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "auth" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\auth.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\auth.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\auth.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\auth.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "entity" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\entity.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\entity.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\entity.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\entity.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "column" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\column.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\column.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\column.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\column.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "relation" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\relation.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\relation.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\relation.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\relation.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "validation" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\validation.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\validation.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\validation.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\validation.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "form" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\form.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\form.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\form.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\form.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "sql" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\sql.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\sql.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\sql.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\sql.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "migration" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\migration.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\migration.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\migration.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\migration.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "seeder" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\seeder.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\seeder.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\seeder.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\seeder.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "menu" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\menu.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\menu.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\menu.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\menu.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "permission" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\permission.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\permission.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\permission.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\permission.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "sidebar" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\sidebar.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\sidebar.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\sidebar.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\sidebar.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "route" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\route.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\route.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\route.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\route.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "api" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\api.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\api.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\api.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\api.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            "openapi" {

                if ([string]::IsNullOrWhiteSpace($Name)) {
                    if ($Force) {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\openapi.ps1" -Force
                    }
                    else {
                        & powershell -ExecutionPolicy Bypass -File "$Generator\openapi.ps1"
                    }
                }
                elseif ($Force) {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\openapi.ps1" -Name $Name -Force
                }
                else {
                    & powershell -ExecutionPolicy Bypass -File "$Generator\openapi.ps1" -Name $Name
                }

                exit $LASTEXITCODE
            }

            default {

                Write-Host ""
                Write-Host "[FAIL] Unknown generator : $Type" -ForegroundColor Red
                Write-Host ""
                exit 1

            }

        }
    }

    "plugin" {

        if ([string]::IsNullOrWhiteSpace($Type)) {
            Write-Host "[FAIL] Missing plugin command." -ForegroundColor Red
            exit 1
        }

        . "$Root\tools\plugin\PluginEngine.ps1"

        switch ($Type.ToLower()) {
            "list" {
                $Plugins = Get-SatsetPluginList
                if ($Plugins.Count -eq 0) {
                    Write-Host "No plugins installed."
                }
                else {
                    foreach ($Plugin in $Plugins) {
                        Write-Host "- $($Plugin.name) ($($Plugin.version)) enabled=$($Plugin.enabled)"
                    }
                }
                exit 0
            }
            "info" {
                if ([string]::IsNullOrWhiteSpace($Name)) {
                    Write-Host "[FAIL] Plugin name is required for info." -ForegroundColor Red
                    exit 1
                }
                try {
                    $Plugin = Get-SatsetPluginInfo -Name $Name
                    $Plugin | ConvertTo-Json -Depth 5
                    exit 0
                }
                catch {
                    Write-Host "[FAIL] $($_.Exception.Message)" -ForegroundColor Red
                    exit 1
                }
            }
            "enable" {
                if ([string]::IsNullOrWhiteSpace($Name)) {
                    Write-Host "[FAIL] Plugin name is required for enable." -ForegroundColor Red
                    exit 1
                }
                try {
                    $Plugin = Enable-SatsetPlugin -Name $Name
                    Write-Host "Plugin '$Name' enabled."
                    exit 0
                }
                catch {
                    Write-Host "[FAIL] $($_.Exception.Message)" -ForegroundColor Red
                    exit 1
                }
            }
            "disable" {
                if ([string]::IsNullOrWhiteSpace($Name)) {
                    Write-Host "[FAIL] Plugin name is required for disable." -ForegroundColor Red
                    exit 1
                }
                try {
                    $Plugin = Disable-SatsetPlugin -Name $Name
                    Write-Host "Plugin '$Name' disabled."
                    exit 0
                }
                catch {
                    Write-Host "[FAIL] $($_.Exception.Message)" -ForegroundColor Red
                    exit 1
                }
            }
            "install" {
                if ([string]::IsNullOrWhiteSpace($Name)) {
                    Write-Host "[FAIL] Plugin name is required for install." -ForegroundColor Red
                    exit 1
                }
                try {
                    $Plugin = Install-SatsetPlugin -Name $Name
                    Write-Host "Plugin '$Name' installed."
                    exit 0
                }
                catch {
                    Write-Host "[FAIL] $($_.Exception.Message)" -ForegroundColor Red
                    exit 1
                }
            }
            "uninstall" {
                if ([string]::IsNullOrWhiteSpace($Name)) {
                    Write-Host "[FAIL] Plugin name is required for uninstall." -ForegroundColor Red
                    exit 1
                }
                try {
                    Uninstall-SatsetPlugin -Name $Name
                    Write-Host "Plugin '$Name' uninstalled."
                    exit 0
                }
                catch {
                    Write-Host "[FAIL] $($_.Exception.Message)" -ForegroundColor Red
                    exit 1
                }
            }
            default {
                Write-Host "[FAIL] Unknown plugin command: $Type" -ForegroundColor Red
                exit 1
            }
        }
    }

    default {

        Write-Host ".\satset.ps1 make auth auth"
        Write-Host ""
        Write-Host "======================================"
        Write-Host " SATSET AI FRAMEWORK"
        Write-Host "======================================"
        Write-Host ""

        Write-Host "Commands"
        Write-Host ""

        Write-Host ".\satset.ps1 doctor"
        Write-Host ".\satset.ps1 make module employee --full"
        Write-Host ".\satset.ps1 make module employee"
        Write-Host ".\satset.ps1 make crud employee"
        Write-Host ".\satset.ps1 make auth auth"
        Write-Host ".\satset.ps1 make entity employee"
        Write-Host ".\satset.ps1 make column employee"
        Write-Host ".\satset.ps1 make relation employee"
        Write-Host ".\satset.ps1 make validation employee"
        Write-Host ".\satset.ps1 make form employee"
        Write-Host ".\satset.ps1 make sql employee"
        Write-Host ".\satset.ps1 make migration employee"
        Write-Host ".\satset.ps1 make seeder employee"
        Write-Host ".\satset.ps1 make menu employee"
        Write-Host ".\satset.ps1 make permission employee"
        Write-Host ".\satset.ps1 make sidebar employee"
        Write-Host ".\satset.ps1 make route employee"
        Write-Host ".\satset.ps1 make api employee"
        Write-Host ".\satset.ps1 make openapi employee"
        Write-Host ".\satset.ps1 plugin list"
        Write-Host ".\satset.ps1 plugin install <name>"
        Write-Host ".\satset.ps1 plugin uninstall <name>"
        Write-Host ".\satset.ps1 plugin enable <name>"
        Write-Host ".\satset.ps1 plugin disable <name>"
        Write-Host ".\satset.ps1 plugin info <name>"
        Write-Host ""
        exit 1

    }

}
