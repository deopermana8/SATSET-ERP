export const {{MODULE}}Service = {};
